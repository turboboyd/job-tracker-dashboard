export { AuthPageShell } from "./AuthPageShell";
export type { AuthPageShellProps } from "./AuthPageShell";
