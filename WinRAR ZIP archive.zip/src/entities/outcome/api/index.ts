export {
  outcomeApi,
  useGetOutcomeQuery,
  useUpsertOutcomeMutation,
  useDeleteOutcomeMutation,
} from "./outcomeApi";
