export { MultiSelectChips } from "./MultiSelectChips";
export type { MultiSelectChipsProps, ChipOption } from "./MultiSelectChips";
